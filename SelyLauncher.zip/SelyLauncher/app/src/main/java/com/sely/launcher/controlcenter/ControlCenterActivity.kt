package com.sely.launcher.controlcenter

import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.sely.launcher.databinding.ActivityControlCenterBinding
import com.sely.launcher.notifications.SelyNotificationListenerService
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Control Center (spec section 3) — redesigned to match a native
 * control-center reference: a real media card, vertical pill
 * brightness/volume sliders, two shortcut capsules, and a core row of
 * circular toggles, with everything this screen used to offer still
 * reachable below under "More controls" (nothing removed).
 *
 * Every control is annotated with its real Android capability tier —
 * this file is the reference implementation of the project's 🟢/🟡/🔴
 * rule (spec §48):
 *
 *  🟢 Flashlight — CameraManager.setTorchMode, no extra permission.
 *  🟢 Do Not Disturb — real toggle via NotificationManager, gated on a
 *     one-time Notification Policy Access grant.
 *  🟢 Volume — AudioManager.setStreamVolume, no special permission.
 *  🟢 Media transport controls — MediaSessionManager.getActiveSessions,
 *     using the same Notification Listener access this app already
 *     requests for Notification Center/the Floating Bubble; when
 *     nothing is actually playing, the card honestly says "Not
 *     Playing" with disabled buttons rather than faking a widget.
 *  🟡 Brightness — requires WRITE_SETTINGS ("Modify system settings"),
 *     which the user must explicitly grant; the slider is disabled
 *     until granted, never faked.
 *  🟡 Wi-Fi — since Android 10, third-party apps (including launchers)
 *     cannot silently flip Wi-Fi on/off. The correct, non-deceptive
 *     approach is Settings.Panel.ACTION_WIFI, Android's own inline
 *     quick-toggle panel.
 *  🟡 Bluetooth — enabling can prompt the system dialog
 *     (ACTION_REQUEST_ENABLE); there is no public API to disable it, so
 *     that case opens Bluetooth settings directly.
 *  🔴 Airplane mode, Hotspot, Location — no public toggle API for any
 *     non-privileged app on modern Android; each is honest about that
 *     and deep-links to the real system screen instead of pretending
 *     to switch it.
 */
class ControlCenterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityControlCenterBinding
    private var torchOn = false
    private var activeMediaController: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityControlCenterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.mediaPrev.setOnClickListener { activeMediaController?.transportControls?.skipToPrevious() }
        binding.mediaNext.setOnClickListener { activeMediaController?.transportControls?.skipToNext() }
        binding.mediaPlayPause.setOnClickListener { toggleMediaPlayback() }

        binding.shortcutGameMode.setOnClickListener {
            startActivity(Intent(this, com.sely.launcher.gamemode.GameModeActivity::class.java))
        }
        binding.shortcutDashboard.setOnClickListener {
            startActivity(Intent(this, com.sely.launcher.dashboard.DeviceDashboardActivity::class.java))
        }

        binding.toggleGrid.layoutManager = GridLayoutManager(this, 4)
        binding.toggleGrid.adapter = CircleTileAdapter(this, buildCoreToggles())

        binding.moreTileGrid.layoutManager = GridLayoutManager(this, 3)
        binding.moreTileGrid.adapter = ControlTileAdapter(this, buildMoreTiles(), iosStyle = true)
        binding.moreToggle.setOnClickListener {
            val showing = binding.moreTileGrid.visibility == View.VISIBLE
            binding.moreTileGrid.visibility = if (showing) View.GONE else View.VISIBLE
            binding.moreToggle.rotation = if (showing) 0f else -90f
        }

        setUpVolumeSlider()
        setUpBrightnessSlider()
    }

    override fun onResume() {
        super.onResume()
        ThemeManager.applyIosCard(binding.root, 28f)
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)
        ThemeManager.applyIosCard(binding.mediaCard, 18f)
        binding.mediaTitle.setTextColor(textPrimary)
        binding.mediaSubtitle.setTextColor(textSecondary)
        binding.brightnessLabel.setTextColor(textSecondary)
        binding.moreToggle.setTextColor(textSecondary)
        binding.shortcutGameModeLabel.setTextColor(textPrimary)
        binding.shortcutDashboardLabel.setTextColor(textPrimary)
        ThemeManager.applyIosCard(binding.shortcutGameMode, 14f)
        ThemeManager.applyIosCard(binding.shortcutDashboard, 14f)

        (binding.toggleGrid.adapter)?.notifyDataSetChanged()
        (binding.moreTileGrid.adapter)?.notifyDataSetChanged()

        refreshMedia()
    }

    // ---- 🟢 Media transport: real MediaSessionManager, honest fallback ----
    private fun refreshMedia() {
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)
        val controller = activeMediaController()
        activeMediaController = controller
        if (controller == null) {
            binding.mediaTitle.text = getString(com.sely.launcher.R.string.not_playing)
            binding.mediaTitle.setTextColor(textSecondary)
            binding.mediaSubtitle.text = "Tap to grant notification access"
            setMediaControlsEnabled(false)
            binding.mediaPlayPause.setImageResource(com.sely.launcher.R.drawable.ic_sely_play)
            return
        }
        val metadata = controller.metadata
        val title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
        val artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
        binding.mediaTitle.text = title ?: controller.packageName
        binding.mediaTitle.setTextColor(textPrimary)
        binding.mediaSubtitle.text = artist ?: ""
        setMediaControlsEnabled(true)
        val playing = controller.playbackState?.state == PlaybackState.STATE_PLAYING
        binding.mediaPlayPause.setImageResource(
            if (playing) com.sely.launcher.R.drawable.ic_sely_pause else com.sely.launcher.R.drawable.ic_sely_play
        )
    }

    private fun setMediaControlsEnabled(enabled: Boolean) {
        val alpha = if (enabled) 1f else 0.35f
        listOf(binding.mediaPrev, binding.mediaPlayPause, binding.mediaNext).forEach {
            it.isEnabled = enabled
            it.alpha = alpha
        }
    }

    private fun toggleMediaPlayback() {
        val controller = activeMediaController ?: run {
            if (!SelyNotificationListenerService.isEnabled(this)) {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                Toast.makeText(this, "Grant Sely notification access to control media here", Toast.LENGTH_LONG).show()
            }
            return
        }
        val playing = controller.playbackState?.state == PlaybackState.STATE_PLAYING
        if (playing) controller.transportControls.pause() else controller.transportControls.play()
    }

    private fun activeMediaController(): MediaController? {
        if (!SelyNotificationListenerService.isEnabled(this)) return null
        return try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(this, SelyNotificationListenerService::class.java)
            manager.getActiveSessions(component).firstOrNull()
        } catch (e: SecurityException) {
            null
        }
    }

    // ---- The 8 real core toggles ----
    private fun buildCoreToggles(): List<ControlTile> = listOf(
        ControlTile("Wi-Fi", com.sely.launcher.R.drawable.ic_sely_wifi) { openWifiPanel() },
        ControlTile("Bluetooth", com.sely.launcher.R.drawable.ic_sely_bluetooth) { toggleBluetooth() },
        ControlTile("Flashlight", com.sely.launcher.R.drawable.ic_sely_flashlight) { toggleFlashlight() },
        ControlTile("DND", com.sely.launcher.R.drawable.ic_sely_dnd) { toggleDnd() },
        ControlTile("Hotspot", com.sely.launcher.R.drawable.ic_sely_hotspot) { openHotspotSettings() },
        ControlTile("Airplane", com.sely.launcher.R.drawable.ic_sely_airplane) { openAirplaneSettings() },
        ControlTile("Location", com.sely.launcher.R.drawable.ic_sely_location) { openLocationSettings() },
        ControlTile("Screenshot", com.sely.launcher.R.drawable.ic_sely_camera) {
            startActivity(Intent(this, com.sely.launcher.screenshotstudio.ScreenshotStudioActivity::class.java))
        }
    )

    // ---- Everything else this screen used to show, still reachable ----
    private fun buildMoreTiles(): List<ControlTile> = listOf(
        ControlTile("Screen Record", com.sely.launcher.R.drawable.ic_sely_record) {
            startActivity(Intent(this, com.sely.launcher.screenrecorder.ScreenRecorderActivity::class.java))
        },
        ControlTile("Network", com.sely.launcher.R.drawable.ic_sely_network) {
            startActivity(Intent(this, com.sely.launcher.network.NetworkCenterActivity::class.java))
        },
        ControlTile("Quick Switch", com.sely.launcher.R.drawable.ic_sely_switch) {
            val target = com.sely.launcher.multitask.LaunchHistoryStore.quickSwitchTarget(this)
            if (target == null) {
                Toast.makeText(this, "Open at least two apps through Sely first", Toast.LENGTH_SHORT).show()
            } else {
                val (packageName, activityName) = target
                val app = com.sely.launcher.AppRepository.resolveApp(this, packageName, activityName)
                if (app != null) {
                    com.sely.launcher.multitask.LaunchHistoryStore.recordLaunch(this, app.packageName, app.activityName)
                    startActivity(Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                        component = ComponentName(app.packageName, app.activityName)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    })
                }
            }
        },
        ControlTile("Recents", com.sely.launcher.R.drawable.ic_sely_recents) {
            startActivity(Intent(this, com.sely.launcher.multitask.MultitaskHubActivity::class.java))
        },
        ControlTile("Settings", com.sely.launcher.R.drawable.ic_sely_settings) {
            startActivity(Intent(this, com.sely.launcher.SettingsActivity::class.java))
        },
        ControlTile("Command Center", com.sely.launcher.R.drawable.ic_sely_command) {
            startActivity(Intent(this, com.sely.launcher.commandcenter.CommandCenterActivity::class.java))
        },
        ControlTile("Clipboard", com.sely.launcher.R.drawable.ic_sely_clipboard) {
            startActivity(Intent(this, com.sely.launcher.clipboard.ClipboardManagerActivity::class.java))
        },
        ControlTile("Files", com.sely.launcher.R.drawable.ic_sely_files) {
            startActivity(Intent(this, com.sely.launcher.filehub.FileHubActivity::class.java))
        },
        ControlTile("QR Scan", com.sely.launcher.R.drawable.ic_sely_qr) {
            startActivity(Intent(this, com.sely.launcher.qrscanner.QrScannerActivity::class.java))
        }
    )

    // ---- 🟢 Flashlight: real, immediate, no special permission ----
    private fun toggleFlashlight() {
        val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cameraManager.setTorchMode(cameraId, torchOn)
        } catch (e: Exception) {
            Toast.makeText(this, "Flashlight unavailable: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ---- 🟢 Do Not Disturb: real toggle, gated on a one-time permission ----
    private fun toggleDnd() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            Toast.makeText(this, "Grant Sely notification policy access, then tap again", Toast.LENGTH_LONG).show()
            return
        }
        val turningOn = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
        nm.setInterruptionFilter(
            if (turningOn) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
    }

    // ---- 🟡 Wi-Fi: Android's own inline panel, not a silent flip ----
    private fun openWifiPanel() {
        startActivity(Intent(Settings.Panel.ACTION_WIFI))
    }

    // ---- 🟡 Bluetooth: can request-enable; disabling has no public API ----
    private fun toggleBluetooth() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            Toast.makeText(this, "No Bluetooth adapter on this device", Toast.LENGTH_SHORT).show()
            return
        }
        if (!adapter.isEnabled) {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
        } else {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
    }

    // ---- 🔴 Airplane mode / Hotspot / Location: no toggle API exists for this app class ----
    private fun openAirplaneSettings() {
        startActivity(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
    }

    private fun openHotspotSettings() {
        try {
            startActivity(Intent("android.settings.WIFI_TETHER_SETTINGS"))
        } catch (e: Exception) {
            Toast.makeText(this, "Open Settings > Hotspot & tethering", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openLocationSettings() {
        startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
    }

    // ---- 🟢 Volume: real, immediate ----
    private fun setUpVolumeSlider() {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        binding.volumeSlider.max = max
        binding.volumeSlider.progress = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        binding.volumeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    // ---- 🟡 Brightness: gated on WRITE_SETTINGS, requested inline ----
    private fun setUpBrightnessSlider() {
        if (!Settings.System.canWrite(this)) {
            binding.brightnessSlider.isEnabled = false
            binding.brightnessLabel.text = "Tap the brightness pill to grant permission"
            binding.brightnessSlider.setOnTouchListener { _, _ ->
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                startActivity(intent)
                true
            }
            return
        }
        binding.brightnessLabel.text = ""
        binding.brightnessSlider.progress = Settings.System.getInt(
            contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128
        )
        binding.brightnessSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }
}
