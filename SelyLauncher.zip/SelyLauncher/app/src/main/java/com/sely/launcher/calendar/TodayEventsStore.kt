package com.sely.launcher.calendar

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import java.util.Calendar

/**
 * Sely Home's "Today" card — real events from the device's own
 * calendar provider (`CalendarContract.Instances`), the same source
 * the system Calendar app itself reads from. Requires READ_CALENDAR,
 * requested inline by the card (see MainActivity); returns an empty
 * list rather than anything invented when the permission isn't
 * granted or there's genuinely nothing scheduled today.
 */
object TodayEventsStore {

    data class TodayEvent(val title: String, val startMillis: Long, val allDay: Boolean)

    fun hasPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun getTodayEvents(context: Context): List<TodayEvent> {
        if (!hasPermission(context)) return emptyList()

        val dayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val dayEnd = dayStart + 24 * 60 * 60 * 1000L

        val uriBuilder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(uriBuilder, dayStart)
        ContentUris.appendId(uriBuilder, dayEnd)

        val projection = arrayOf(
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.ALL_DAY
        )

        val events = mutableListOf<TodayEvent>()
        try {
            context.contentResolver.query(
                uriBuilder.build(), projection, null, null,
                "${CalendarContract.Instances.BEGIN} ASC"
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val title = cursor.getString(0) ?: continue
                    val begin = cursor.getLong(1)
                    val allDay = cursor.getInt(2) != 0
                    events.add(TodayEvent(title, begin, allDay))
                }
            }
        } catch (e: SecurityException) {
            return emptyList()
        }
        return events
    }
}
