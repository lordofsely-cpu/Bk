package com.sely.launcher.controlcenter

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

/**
 * Circular toggle icon grid for Control Center's core row (Wi-Fi,
 * Bluetooth, Flashlight, DND, Hotspot, Airplane, Location, Screenshot).
 * Reuses the same `ControlTile` model as the square-tile adapter —
 * only the item shape differs, not the underlying data or real
 * click behavior.
 */
class CircleTileAdapter(
    private val context: Context,
    private val tiles: List<ControlTile>
) : RecyclerView.Adapter<CircleTileAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.circleIcon)
        val label: TextView = view.findViewById(R.id.circleLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_circle_tile, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = tiles.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tile = tiles[position]
        holder.icon.setImageResource(tile.iconRes)
        holder.icon.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (ThemeManager.isDark(context)) 0xFF2C2C2E.toInt() else 0xFFE5E5EA.toInt())
        }
        holder.label.text = tile.label
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.itemView.setOnClickListener { tile.onClick() }
    }
}
