package com.sely.launcher.widgets

import android.content.Context

/** Remembers which widget (if any) is placed in Home's widget slot. */
object HomeWidgetPrefs {
    private const val PREFS = "sely_home_widget"
    private const val KEY_WIDGET_ID = "widget_id"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getWidgetId(context: Context): Int = prefs(context).getInt(KEY_WIDGET_ID, -1)

    fun setWidgetId(context: Context, id: Int) {
        prefs(context).edit().putInt(KEY_WIDGET_ID, id).apply()
    }

    fun clear(context: Context) {
        prefs(context).edit().remove(KEY_WIDGET_ID).apply()
    }
}
