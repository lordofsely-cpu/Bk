package com.sely.launcher.bubble

import android.app.Notification
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

/**
 * Renders the real message history a chat notification carries, via
 * `Notification.MessagingStyle` — the standard API WhatsApp, Messenger,
 * Telegram, SMS and most chat apps use to build their notifications.
 *
 * 🟡 Honest limit, shown in the window itself too: this is only
 * whatever messages the source app chose to include in the
 * notification payload (typically the last several) — not that app's
 * complete conversation history, which Sely has no access to.
 */
class MiniChatAdapter(
    private val context: Context,
    private val messages: List<Notification.MessagingStyle.Message>
) : RecyclerView.Adapter<MiniChatAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val sender: TextView = view.findViewById(R.id.chatMsgSender)
        val text: TextView = view.findViewById(R.id.chatMsgText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_mini_chat_message, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = messages.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val message = messages[position]
        // getSenderPerson() only exists from API 28 — this app supports
        // API 26+, and calling it on an older device would crash with a
        // real NoSuchMethodError (which a plain catch-Exception block
        // would NOT catch, since Error isn't an Exception), so the SDK
        // check has to come first, not just a try/catch.
        val senderName = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            try {
                message.senderPerson?.name?.toString()
            } catch (e: Exception) {
                null
            }
        } else {
            null
        } ?: message.sender?.toString() ?: "Them"

        holder.sender.text = senderName
        holder.text.text = message.text
        holder.sender.setTextColor(ThemeManager.textSecondary(context))
        holder.text.setTextColor(ThemeManager.textPrimary(context))
    }
}
