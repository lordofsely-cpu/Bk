package com.sely.launcher.widgets

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent

/**
 * Sely Home's widget slot — one real Android widget (weather, a
 * calendar app's own widget, anything), the same genuine mechanism
 * as Desktop Mode's widget canvas and the real Android home screen
 * itself (`AppWidgetHost`). A different host ID from Desktop Mode's
 * (10415) so the two don't collide if both are ever active.
 *
 * Deliberately single-slot and fixed-size here, unlike Desktop Mode's
 * free-position canvas — Home already has a tightly laid-out grid, so
 * this is one bounded widget area near the top, not an open canvas.
 */
class HomeWidgetHost(private val activity: Activity) {

    companion object {
        const val HOST_ID = 10416
        const val REQUEST_PICK_WIDGET = 9301
        const val REQUEST_BIND_WIDGET = 9302
        const val REQUEST_CONFIGURE_WIDGET = 9303
    }

    private val appWidgetManager = AppWidgetManager.getInstance(activity)
    val appWidgetHost = AppWidgetHost(activity, HOST_ID)
    private var pendingConfigureWidgetId: Int? = null

    fun startListening() = appWidgetHost.startListening()
    fun stopListening() = appWidgetHost.stopListening()

    fun beginAddWidget() {
        val widgetId = appWidgetHost.allocateAppWidgetId()
        val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
        }
        activity.startActivityForResult(intent, REQUEST_PICK_WIDGET)
    }

    fun providerInfo(widgetId: Int): AppWidgetProviderInfo? = appWidgetManager.getAppWidgetInfo(widgetId)

    fun createHostView(widgetId: Int, info: AppWidgetProviderInfo): AppWidgetHostView =
        appWidgetHost.createView(activity, widgetId, info)

    fun deleteWidget(widgetId: Int) = appWidgetHost.deleteAppWidgetId(widgetId)

    fun handleActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Int? {
        val widgetId = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)?.takeIf { it != -1 }

        if (resultCode != Activity.RESULT_OK) {
            (widgetId ?: pendingConfigureWidgetId)?.let { appWidgetHost.deleteAppWidgetId(it) }
            pendingConfigureWidgetId = null
            return null
        }

        return when (requestCode) {
            REQUEST_PICK_WIDGET -> {
                val id = widgetId ?: return null
                val info = appWidgetManager.getAppWidgetInfo(id) ?: return null
                if (info.configure != null) {
                    val configIntent = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
                        component = info.configure
                        putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    }
                    pendingConfigureWidgetId = id
                    try {
                        activity.startActivityForResult(configIntent, REQUEST_CONFIGURE_WIDGET)
                    } catch (e: Exception) {
                        pendingConfigureWidgetId = null
                        return id
                    }
                    null
                } else {
                    id
                }
            }
            REQUEST_CONFIGURE_WIDGET -> {
                val id = pendingConfigureWidgetId
                pendingConfigureWidgetId = null
                id
            }
            else -> null
        }
    }
}
